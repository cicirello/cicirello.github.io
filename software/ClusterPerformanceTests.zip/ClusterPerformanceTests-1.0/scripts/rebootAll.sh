#!/bin/bash
ssh rpi1.local 'sudo shutdown -r now'
ssh rpi2.local 'sudo shutdown -r now'
ssh rpi3.local 'sudo shutdown -r now'
ssh rpi4.local 'sudo shutdown -r now'
ssh rpi5.local 'sudo shutdown -r now'
ssh rpi6.local 'sudo shutdown -r now'
ssh rpi7.local 'sudo shutdown -r now'

