#!/bin/bash
ssh rpi1.local 'sudo shutdown now'
ssh rpi2.local 'sudo shutdown now'
ssh rpi3.local 'sudo shutdown now'
ssh rpi4.local 'sudo shutdown now'
ssh rpi5.local 'sudo shutdown now'
ssh rpi6.local 'sudo shutdown now'
ssh rpi7.local 'sudo shutdown now'

